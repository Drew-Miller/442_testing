package com.puppycrawl.tools.checkstyle.checks.design;

public enum InputOneTopLevelEnum {
    VALUE1, VALUE2;
}
