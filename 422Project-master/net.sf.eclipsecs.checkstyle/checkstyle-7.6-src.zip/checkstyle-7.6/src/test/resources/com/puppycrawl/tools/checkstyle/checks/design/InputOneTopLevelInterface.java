package com.puppycrawl.tools.checkstyle.checks.design;

public interface InputOneTopLevelInterface {
    int foo();
}
