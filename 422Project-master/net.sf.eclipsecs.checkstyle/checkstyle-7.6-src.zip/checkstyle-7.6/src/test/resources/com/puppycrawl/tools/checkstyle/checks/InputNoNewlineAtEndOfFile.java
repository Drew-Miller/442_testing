////////////////////////////////////////////////////////////////////////////////
// Test case file for checkstyle.
// Created: 2003
////////////////////////////////////////////////////////////////////////////////
package com.puppycrawl.tools.checkstyle.checks;

/**
 * Test case for detection of missing newlines at EOF, using the
 * NewlineAtEndOfFileCheck.
 * @author Christopher Lenz
 **/
public interface InputNoNewlineAtEndOfFile
{
}