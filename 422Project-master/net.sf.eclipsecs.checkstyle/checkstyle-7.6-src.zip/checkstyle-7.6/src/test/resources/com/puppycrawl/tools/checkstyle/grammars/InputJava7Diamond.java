package com.puppycrawl.tools.checkstyle.grammars;

import java.util.*;

public class InputJava7Diamond {
	HashMap<String, Integer> map = new HashMap<String, Integer>();
	HashMap<String, Integer> map2 = new HashMap<>();
	HashMap<String, HashMap<Integer, Integer>> map3 = new HashMap<>();
	ArrayList<String> list = new ArrayList<>();
}
