package com.puppycrawl.tools.checkstyle.checks.design;

import com.puppycrawl.tools.checkstyle.checks.coding.InputGregorianCalendar;
import com.puppycrawl.tools.checkstyle.checks.design.InetSocketAddress;
public final class InputImmutableSameTypeName
{
    public final java.util.GregorianCalendar calendar = null;
    public final InputGregorianCalendar calendar2 = null;
    public final com.puppycrawl.tools.checkstyle.checks.coding.InputGregorianCalendar calendar3 = null;
    public final InetSocketAddress address = null;
    public final java.net.InetSocketAddress adr = null;
}
