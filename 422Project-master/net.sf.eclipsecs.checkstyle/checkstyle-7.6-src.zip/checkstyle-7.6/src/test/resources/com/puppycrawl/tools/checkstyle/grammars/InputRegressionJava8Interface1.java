//Compilable with Java8
package com.puppycrawl.tools.checkstyle.grammars;

public interface InputRegressionJava8Interface1 {
    default void m() {}
}